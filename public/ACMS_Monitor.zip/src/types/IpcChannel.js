export var IpcChannel;
(function (IpcChannel) {
    IpcChannel["UiCommand"] = "UiCommand";
    IpcChannel["UpdateData"] = "UpdateUpdateData";
})(IpcChannel || (IpcChannel = {}));
//# sourceMappingURL=IpcChannel.js.map