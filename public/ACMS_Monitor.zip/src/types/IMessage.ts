

export interface IMessage
{
    Message: string;
    Timestamp: string;
    Server: string;
    Level: string;
    Id: number;
}