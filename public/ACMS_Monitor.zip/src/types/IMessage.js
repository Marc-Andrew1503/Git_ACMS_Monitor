export {};
//# sourceMappingURL=IMessage.js.map