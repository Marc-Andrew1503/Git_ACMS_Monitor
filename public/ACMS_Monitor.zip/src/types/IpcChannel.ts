
export enum IpcChannel {
    UiCommand = "UiCommand",
    UpdateData ="UpdateUpdateData"
}