<template>
<div>
  <h1>Ich bin der filter header</h1>
</div>
</template>

<script>
export default {

}
</script>

<style>

</style>