<template>
  <div class="adbsgStatus">Standard mode | Copyright 2021 ADB Safegate Germany</div>
</template>

<script>
export default {

}
</script>

<style>
    .adbsgStatus{
        border-color: black;
        border: 1px;
        text-align: left;
        background-color:darkgrey;
        height: 30px;
        width: 100%;
        position: absolute;
        bottom: 0px;
    }

</style>